#24. Write a python program for printing Fibonacci series

n = int(input("Enter number of terms: "))
a = 0
b = 1
print("Fibonacci Series:")

for i in range(n):
    print(a, end=" ")

    c = a + b
    a = b
    b = c